# Bennett Music Player - System Requirements

**Master Document** - Reference this before making any changes.  
**Last Updated**: 2026-02-22
**Current Version**: 3.0.53

---

## Core Principles

### Source of Truth
**MP3 files are the source of record for all song and album-related information.**

- Song title → from MP3 ID3 tag
- Artist → from MP3 ID3 tag  
- Album name → from MP3 ID3 tag
- Track number → from MP3 ID3 tag
- Year → from MP3 ID3 tag
- Embedded cover art → from MP3 ID3 tag

The database stores this information for performance, but the MP3 files are authoritative. If there's a conflict, the MP3 file is correct.

### Design Philosophy
1. **Simple over complex** - Don't add layers of abstraction
2. **Files are truth** - Database reflects files, not vice versa
3. **Flexible matching** - Accommodate variations in naming
4. **Fail gracefully** - Missing data shouldn't break the system

---

## Development & Testing Environment

### Local Setup
The app runs locally via **Laravel Herd** at `http://music.test`. The codebase lives alongside the main `glennbennett.com` site on the same machine.

### Song Files Must Be on the Same Server
The MP3 files and cover art images are **not part of this repository**. They live in a sibling directory on the filesystem:

```
/Users/bennett/Herd/
├── music/                    ← This app (music.test)
├── glennbennett/
│   └── songs/                ← MP3 files + cover art (music_origin_path)
│       ├── *.mp3
│       └── imgs/
└── glennbennett.com/
    └── songs/                ← Alternate path (production layout)
```

The `music_origin_path` config resolves via `realpath()` trying both sibling paths:
```php
realpath(FCPATH . '/../glennbennett/songs')   // local dev
?: realpath(FCPATH . '/../glennbennett.com/songs')  // production
```

**If the song files aren't present on the machine, these features break:**
- Library scanner — can't find MP3 files to read metadata from
- Share image generation — can't load cover art for GD compositing (falls back to placeholder)
- Admin diagnostics — filesystem checks will fail

**These features still work without local song files:**
- Audio playback — streams from CDN (`glb-songs.b-cdn.net`), not from local filesystem
- Cover art display in the player — loaded from CDN URLs
- All player functionality — the app only needs the database and CDN

### Dev vs Production Differences
| Aspect | Local Dev (`music.test`) | Production (`music.glennbennett.com`) |
|--------|--------------------------|---------------------------------------|
| `base_url` | Auto-detected from `$_SERVER['HTTP_HOST']` | Auto-detected (same code) |
| Song files | `../glennbennett/songs/` | `../glennbennett.com/songs/` |
| Audio streaming | CDN (same as production) | CDN |
| Cover images | CDN (same as production) | CDN |
| Share images | Generated from local files | Generated from local files |
| Database | `music_local` via root@localhost | Production MySQL |
| PHP | PHP 8.1 via Herd | PHP 8.1 |

### Testing Complications
1. **JS/CSS changes take effect immediately** on `music.test` — no deployment needed. But phone testing requires the phone to be on the same network and accessing `music.test` (not the production URL).
2. **`base_url` must auto-detect** — previously hardcoded to production, which caused local page loads to pull JS/CSS from `music.glennbennett.com` instead of `music.test`. All local JS changes appeared to have no effect. See config.php.
3. **CDN caching** — audio and cover art are served from Bunny CDN. Changes to actual song files or cover images may take time to propagate. The `?h=` cache-busting parameter helps, but only after a rescan updates the file hash in the database.
4. **Share image testing** — can be done locally at `music.test/share/image?song=ID` and `music.test/admin/share_images`. But Facebook's crawler can only reach the production URL, so testing with the Facebook Sharing Debugger requires deploying first.

### How Code Updates Reach the Browser

This is the most common source of "my change didn't work" confusion. Here is exactly how it works:

**The update chain:**
1. Developer bumps version in 4 places (sw.js, index.php x2, REQUIREMENTS.md)
2. User loads/reloads the page
3. Browser detects `sw.js` changed → downloads and installs new SW
4. New SW calls `skipWaiting()` + `clients.claim()` → takes control immediately
5. New SW's `activate` event deletes old version caches
6. Next page load: fresh HTML (network-first) → has new `?v=X.Y.Z` query strings → fresh JS/CSS (network-first)

**As of v3.0.52, ALL request types use network-first** (HTML, JS, CSS, API calls). This means:
- When **online**: always fetches fresh from server, then caches for offline use
- When **offline**: falls back to cached version
- Audio and images are the exception — audio uses cache-first for offline playback

**Why this matters for development:**
- After changing code, a simple page reload should pick up changes immediately
- No need to manually clear caches, hard-refresh, or unregister service workers
- The `?v=3.0.X` query strings on JS/CSS tags act as cache-busters for any intermediate CDN or browser HTTP cache
- The only time a manual hard-refresh (`Cmd+Shift+R`) is needed is if the SW itself hasn't been updated yet (e.g., the very first reload after deployment)

**If changes still aren't visible after reload:**
1. Check DevTools Console for the SW version: `[SW] Service Worker loaded, version: X.Y.Z`
2. If it shows an old version, the browser hasn't fetched the new `sw.js` yet — do a hard refresh
3. Check DevTools → Application → Service Workers — if "waiting to activate" is shown, click "skipWaiting"
4. Nuclear option: Application → Storage → Clear site data

**NEVER go back to cache-first for static assets.** Cache-first was the root cause of many "my changes don't show up" bugs. Network-first costs a tiny bit of latency but guarantees updates are visible immediately.

---

## Architecture

### Stack
- **Framework**: CodeIgniter 3.x (PHP)
- **Database**: MySQL/MariaDB
- **Frontend**: Vanilla JavaScript, CSS
- **PWA**: Service Worker for offline capability
- **CDN**: Bunny CDN for media delivery

### Key Files
```
application/
├── config/
│   ├── config.php            # base_url (auto-detect!), session, etc.
│   └── music_config.php      # CDN URLs, paths, settings
├── controllers/
│   ├── Admin.php             # Admin interface
│   ├── Api.php               # Public JSON API (albums, songs, favorites, plays, shares)
│   ├── Player.php            # Main player page + player-specific AJAX endpoints
│   └── Share.php             # Social sharing images & OG redirect pages
├── models/
│   ├── Album_model.php       # Album CRUD & cover URLs
│   ├── Favorite_model.php    # ALL favorites logic (song + album favorites)
│   └── Song_model.php        # Song CRUD, URLs, library scanner
└── views/
    ├── admin/
    │   ├── albums.php        # Album management
    │   └── songs.php         # Library view with diagnostics
    └── player/
        └── index.php         # Main player interface (server-rendered first load)

assets/
├── css/
│   └── music-player.css      # All player styles
└── js/
    └── music-player.js       # All player JS (the ACTIVE file — NOT root music-player.js)

sw.js                          # Service worker (versioned, must stay in sync)
database/schema.sql            # Reference schema (old backups — don't edit)
```

---

## File Structure

### Music Directory (`/songs/`)
```
/songs/
├── *.mp3                     # Audio files (flat, no subdirectories)
├── imgs/
│   ├── albums/               # Album cover art (manually placed)
│   │   ├── milestones.jpg
│   │   └── {album-name}.{ext}
│   └── songs/                # Song covers (extracted from ID3)
│       └── {hash}.webp
```

### Audio Files
- Location: `/songs/*.mp3` (root level, flat structure)
- Format: MP3
- Naming: Matches song title (e.g., `Colorado Snow.mp3`)

### Album Cover Images
- Location: `/songs/imgs/albums/`
- Naming: Matches album title with flexible matching
- Formats: jpg, jpeg, png, webp, gif

### Song Cover Images
- Location: `/songs/imgs/songs/`
- Naming: `{hash}.webp` where hash is from file content
- Source: Extracted from MP3 ID3 embedded artwork during scan

---

## How Files Are Accessed (Streaming & Serving)

### Overview
Files are stored on the origin server filesystem but served to the browser via Bunny CDN. The app never streams audio or images directly from the origin — it always constructs CDN URLs.

### Audio Streaming
1. Database stores `songs.filename` (e.g., `Colorado Snow.mp3`)
2. `Song_model::get_stream_url()` builds the CDN URL:
   ```
   {music_cdn_url}/{filename}?h={file_hash_prefix}
   ```
3. Example: `https://glb-songs.b-cdn.net/songs/Colorado Snow.mp3?h=a1b2c3d4e5`
4. The `?h=` parameter is cache-busting — uses first 10 chars of the file's MD5 hash
5. If `music_cdn_url` is empty, no stream URL is generated (songs won't play)

### Song Cover Art URLs
1. Database stores `songs.cover_filename` (e.g., `songs/abc123.webp`)
2. `Song_model::get_cover_url()` builds the CDN URL:
   ```
   {cover_art_url}/{cover_filename}?h={file_hash_prefix}
   ```
3. Example: `https://glb-songs.b-cdn.net/songs/imgs/songs/abc123.webp?h=a1b2c3d4`
4. Falls back to `base_url('uploads/covers/{cover_filename}')` if no CDN URL configured
5. Returns `null` if song has no `cover_filename`

### Album Cover Art URLs
1. `Album_model::get_cover_url()` first scans the filesystem at `{music_origin_path}/imgs/albums/` using flexible name matching
2. If a matching file is found:
   ```
   {cover_art_url}/albums/{matched_filename}
   ```
3. Example: `https://glb-songs.b-cdn.net/songs/imgs/albums/milestones.jpg`
4. If no filesystem match, falls back to `albums.cover_filename` from database:
   ```
   {cover_art_url}/{cover_filename}
   ```

### Config Values (from `music_config.php`)
| Config Key | Purpose | Example |
|------------|---------|---------|
| `music_origin_path` | Local filesystem path to MP3s and images | `/path/to/glennbennett/songs` |
| `music_cdn_url` | CDN base URL for streaming audio | `https://glb-songs.b-cdn.net/songs` |
| `cover_art_url` | CDN base URL for cover images | `https://glb-songs.b-cdn.net/songs/imgs/` |
| `cover_art_path` | Local filesystem path for cover images | Derived from `music_origin_path` + `/imgs/` |

### Flow: Browser Requests a Song
```
Browser → CDN URL (glb-songs.b-cdn.net/songs/Colorado Snow.mp3)
       → Bunny CDN checks cache
       → If miss: pulls from origin (glennbennett.com/songs/Colorado Snow.mp3)
       → Caches and serves to browser
       → Service Worker caches for offline playback
```

### Share Image Generation (Server-Side)
Share images (`/share/image?song=ID`) are the one case where the **server reads files directly from the filesystem** (not via CDN):
- `Share::image()` loads cover art from `{music_origin_path}/imgs/` using `imagecreatefromjpeg()` etc.
- This is because GD library needs a local file path, not a URL
- The generated JPEG is served directly from PHP, not cached on CDN

---

## Database Schema

### `albums` Table
| Column | Type | Description |
|--------|------|-------------|
| id | INT | Primary key |
| title | VARCHAR | Album name (from MP3 tag) |
| artist | VARCHAR | Album artist |
| year | INT | Release year |
| cover_filename | VARCHAR | Fallback cover path (if no filesystem match) |
| description | TEXT | Optional description |
| release_date | DATE | Optional release date |
| created_at | DATETIME | Record creation |
| updated_at | DATETIME | Last update |

### `songs` Table
| Column | Type | Description |
|--------|------|-------------|
| id | INT | Primary key |
| filename | VARCHAR | Audio filename (e.g., `Colorado Snow.mp3`) |
| title | VARCHAR | Song title (from MP3 tag) |
| artist | VARCHAR | Song artist (from MP3 tag) |
| duration | INT | Duration in seconds |
| file_hash | VARCHAR | MD5 hash of file (for change detection) |
| cover_filename | VARCHAR | Path to extracted cover image |
| created_at | DATETIME | When added to database |
| updated_at | DATETIME | Last metadata update |

### `album_songs` Table (Junction)
| Column | Type | Description |
|--------|------|-------------|
| id | INT | Primary key |
| album_id | INT | FK to albums |
| song_id | INT | FK to songs |
| track_number | INT | Track position (from MP3 tag) |

### `devices` Table
| Column | Type | Description |
|--------|------|-------------|
| id | VARCHAR(64) | Primary key (UUID from client localStorage) |
| name | VARCHAR(100) | Optional device name |
| user_agent | VARCHAR(500) | Browser user agent string |
| ip_address | VARCHAR(45) | Last known IP |
| excluded | TINYINT | Whether to exclude from stats |
| first_seen | TIMESTAMP | When device first appeared |
| last_seen | TIMESTAMP | Last activity (updated on every API call) |
| play_count | INT | Total plays from this device |

### `favorites` Table
| Column | Type | Description |
|--------|------|-------------|
| device_id | VARCHAR(64) | FK to devices.id |
| song_id | INT | FK to songs.id |
| sort_order | INT | Display order within device's favorites |
| created_at | DATETIME | When favorited |

**Primary key**: `(device_id, song_id)`

### `favorite_albums` Table
| Column | Type | Description |
|--------|------|-------------|
| device_id | VARCHAR(64) | FK to devices.id |
| album_id | INT | FK to albums.id |
| created_at | DATETIME | When favorited |

**Primary key**: `(device_id, album_id)`

### `play_history` Table
| Column | Type | Description |
|--------|------|-------------|
| id | INT | Primary key |
| song_id | INT | FK to songs |
| user_id | INT | FK to users (nullable) |
| device_id | VARCHAR(64) | FK to devices.id |
| played_at | DATETIME | When played |
| duration | INT | Song duration in seconds |
| listened | INT | Seconds actually listened |
| percent | TINYINT | Percentage of song listened (0-100) |

### `share_history` Table
| Column | Type | Description |
|--------|------|-------------|
| id | INT | Primary key |
| song_id | INT | FK to songs (0 if album share) |
| album_id | INT | FK to albums (0 if song share) |
| device_id | VARCHAR(64) | Device that shared |
| share_method | VARCHAR(50) | How shared (facebook, twitter, native, copy) |
| share_type | VARCHAR(20) | "song" or "album" |
| shared_at | TIMESTAMP | When shared |

### `share_clicks` Table
| Column | Type | Description |
|--------|------|-------------|
| id | INT | Primary key |
| song_id | INT | Song that was shared |
| album_id | INT | Album that was shared |
| from_device_id | VARCHAR(64) | Device that originally shared |
| to_device_id | VARCHAR(64) | Device that clicked the link |
| referrer | TEXT | HTTP referrer |
| share_type | VARCHAR(20) | "song" or "album" |
| clicked_at | TIMESTAMP | When clicked |

---

## Album Cover Art System

### Lookup Priority
1. **FIRST**: Scan filesystem `/songs/imgs/albums/` with flexible matching
2. **SECOND**: Fall back to `albums.cover_filename` from database

### Flexible Matching Algorithm
```php
// Normalize for comparison: lowercase, remove all separators
$album_normalized = strtolower(str_replace(['_', ' ', '-'], '', $album->title));
$file_normalized = strtolower(str_replace(['_', ' ', '-'], '', $file_basename));
if ($file_normalized === $album_normalized) { /* match! */ }
```

### Match Examples
| File | Album Title | Match? |
|------|-------------|--------|
| `milestones.jpg` | Milestones | ✓ |
| `Milestones.jpg` | Milestones | ✓ |
| `MILESTONES.PNG` | Milestones | ✓ |
| `mile_stones.jpg` | Milestones | ✓ |
| `Mile-Stones.jpg` | Milestones | ✓ |
| `mile stones.jpg` | Milestones | ✓ |

### Supported Formats
jpg, jpeg, png, webp, gif

### URL Construction
```php
// If found in filesystem:
$url = $cover_art_url . '/albums/' . $filename;
// Example: https://glb-songs.b-cdn.net/songs/imgs/albums/milestones.jpg

// If using database fallback:
$url = $cover_art_url . '/' . $album->cover_filename;
```

---

## Song Cover Art System

### Source
Extracted from MP3 ID3 embedded artwork during library scan.

### Storage
- Saved to `/songs/imgs/songs/{hash}.webp`
- Hash derived from audio file content
- Converted to WebP format for efficiency

### Lookup Priority
1. Song's own `cover_filename` from database
2. Fall back to album cover

---

## Library Scanner

### Trigger
- Admin: Dashboard → "Scan Library" button
- URL: `/admin/scan_library`

### Behavior
1. Scan `/songs/` directory for MP3 files
2. For each MP3:
   - Read ID3 tags (title, artist, album, track, year)
   - Calculate file hash
   - Extract embedded cover art (if present)
   - Check if song exists in database (by filename)
   - Create or update song record
3. Group songs by album tag
4. Create/update album records
5. Link songs to albums via `album_songs`

### Album Creation Rules
- Albums created from unique MP3 "album" tag values
- Album artist = most common artist in album's songs
- Album year = most common year in album's songs

### Misc Album
The "Misc" album is a catch-all for songs that don't belong to a named album:
- Songs with **no album tag** in their MP3 metadata → assigned to "Misc"
- Songs with an album tag but **fewer songs than `min_album_songs`** (default: 2) → grouped into "Misc"
- The album name is always **"Misc"** (not "Unknown Album", not "Miscellaneous")
- **This is not an error** - it's expected behavior for standalone tracks, singles, or untagged files
- Misc songs appear in the player's album dropdown like any other album
- In the admin view, Misc songs are shown with a green border (informational, not a warning)

### Cover Art During Scan
1. Check `/songs/imgs/albums/` for matching cover (flexible matching)
2. If not found, extract embedded cover from MP3
3. Store extracted cover in `/songs/imgs/songs/`

---

## Admin Interface

### Dashboard (`/admin`)
- Statistics: albums, songs, plays, users
- Quick actions: Scan, Upload, etc.
- System info: paths, CDN URLs, last scan

### Library View (`/admin/songs`)

#### Albums Tab
Shows each album with:
- Cover image (from filesystem or database)
- Title, artist, year, song count
- Diagnostic issues (if any)
- Song list sorted by **file track number**

#### Table Columns
| Column | Source | Purpose |
|--------|--------|---------|
| Row | Display order | Position after sorting |
| File# | MP3 ID3 tag | Track number from file (source of truth) |
| DB# | database | Track number in database (reference only) |
| Title | MP3 ID3 tag | Song title |
| Artist (MP3) | MP3 ID3 tag | Artist from file |
| Album (MP3) | MP3 ID3 tag | Album from file (for mismatch detection) |

#### Diagnostic Issues
| Issue | Severity | Meaning |
|-------|----------|---------|
| album-mismatch | Error | MP3 album tag ≠ assigned album |
| MISSING-FILE | Error | Audio file not on disk |
| no-file-track | Warning | MP3 has no track number |

#### Miscellaneous Section
- Shows songs not assigned to any album
- **Informational only** - not an error
- Green border (not yellow/red)

#### Sortable Tables
- Click column header to sort
- Click again to reverse
- ⇅ = sortable, ↑ = ascending, ↓ = descending

### Songs Detail Tab
Full table of all songs with:
- ID, title, artist, album, track#
- Filename, cover file, duration
- Play count, file hash
- Created/updated timestamps
- Status indicator

### Files Tab
- Lists all MP3 files on disk
- Shows which are in database
- Delete button for each file

---

## Player Interface

### Features
- Album browsing with cover art
- Track listing with play controls
- Now playing bar with progress scrubbing
- Shuffle and repeat modes
- Keyboard shortcuts
- Favorites (per-device, heart icon on each track)
- PWA support (installable, offline capable)
- CarPlay / lock screen controls via MediaSession API
- Background playback recovery after phone sleep or app suspension

### Album Dropdown
- Lists all real albums from the database first
- "Favorites" option appears dynamically at the end (before Misc) only when the device has favorites
- "Misc Songs" option appears at the very end if there are unassigned songs
- Order: `[Album 1] [Album 2] ... [Favorites] [Misc Songs]`
- Switching albums loads the new album's tracks without interrupting playback until data is ready
- If album load fails, the dropdown reverts to the previous selection

### Track List Rendering
- Each track row shows: cover thumbnail (or track number), title, artist, duration
- **Songs with `cover_url`**: Show a 44x44 rounded thumbnail image (`.track-thumb`)
- **Songs without `cover_url`**: Show the track number as text (`.track-number`)
- Duration is calculated using `Number(s.duration)` — duration comes from API as a STRING
- Total album duration: `songs.reduce((sum, s) => sum + (Number(s.duration) || 0), 0)`

### Album Cover Display
- **Real albums with `cover_url`**: Show the album cover image (`.album-cover`)
- **Favorites with songs**: Show stacked covers — up to 3 unique song cover images fanned from bottom-left to upper-right with rotation and shadows (`.stacked-covers.count-N`)
- **Albums without cover**: Show a placeholder with the first letter of the title (`.album-cover.placeholder`)

### Play Button Behavior
- The master Play button (`id="mainPlayBtn"`) and per-track play buttons stay in sync
- `mainPlayToggle()` toggles play/pause state; if nothing is loaded, starts from track 1
- All play/pause icons update together via `updatePlayPauseIcons()`

### CarPlay / Lock Screen (MediaSession)
- Uses the MediaSession API to show album art, title, and artist on lock screen and CarPlay
- **Previous/Next track**: registered as `previoustrack` / `nexttrack` handlers
- **Seek backward/forward**: Mapped to `previousTrack()` / `nextTrack()` so pressing them skips tracks
- **IMPORTANT**: All action handlers (play, pause, previoustrack, nexttrack, seekbackward, seekforward) must be re-registered every time track metadata changes. iOS Safari drops handlers when `navigator.mediaSession.metadata` is updated. The handlers are registered in both `setupMediaSession()` (init) and `updateMediaSession()` (every track change).
- **Position state**: `setPositionState()` is called with duration/position so iOS knows the track length
- **Artwork**: Multiple sizes provided (96-512px) for different display contexts (lock screen, Control Center, CarPlay)

### Background Playback Recovery
- When the page becomes visible again (`visibilitychange` event), the player calls `handleResume()`
- `handleResume()` re-registers MediaSession, syncs the play/pause state with the actual audio element state, and recovers stalled audio if needed
- `recoverPlayback()` saves the current position, reloads the audio source, and resumes from where it left off

### Keyboard Shortcuts
| Key | Action |
|-----|--------|
| Space | Play/Pause |
| ← | Previous track |
| → | Next track |
| ↑ | Volume up |
| ↓ | Volume down |
| M | Mute/Unmute |
| S | Toggle shuffle |
| R | Toggle repeat |

---

## API Endpoints

There are TWO controllers that serve JSON: `Player.php` (used by the player UI) and `Api.php` (general-purpose API). All responses return `{ "success": true/false, ... }`.

**IMPORTANT: All numeric fields (duration, id, track_number) come from the API as STRINGS, not numbers. Always use `Number()` or `parseInt()` in JS when doing arithmetic.**

### Device Identification
- All requests include `X-Device-Id` header (a UUID stored in localStorage)
- `Api.php` auto-registers the device on every request via `_touch_device()`
- `Player.php` relies on `Favorite_model::ensure_device()` to create device rows on-demand
- The device_id is used for favorites, play history, and share tracking

### Player Controller (`/player/*`)

| Endpoint | Method | Headers | Description |
|----------|--------|---------|-------------|
| `/player` | GET | — | Main player page (server-rendered HTML) |
| `/player/album/{id}` | GET | `X-Device-Id` | Get album with songs. `id` can be a numeric album ID, `"favorites"`, or `"misc"` |
| `/player/record_play` | POST | `X-Device-Id` | Record a play event. Body: `song_id` |
| `/player/toggle_favorite` | POST | `X-Device-Id` | Toggle song favorite. Body: `song_id` (form-encoded, NOT JSON) |
| `/player/is_favorite` | GET | `X-Device-Id` | Check if song is favorited. Query: `?song_id=X` |
| `/player/favorites` | GET | `X-Device-Id` | Get all favorited songs for this device |
| `/player/log_event` | POST | — | Log client events (dev only) |

### Api Controller (`/api/*`)

| Endpoint | Method | Headers | Description |
|----------|--------|---------|-------------|
| `/api/albums` | GET | — | List all albums (paginated via `?page=N`) |
| `/api/album/{id}` | GET | — | Get single album with songs (numeric ID only) |
| `/api/misc` | GET | — | Get Misc virtual album with unassigned songs |
| `/api/songs` | GET | — | List all songs (paginated) |
| `/api/song/{id}` | GET | — | Get single song with album info |
| `/api/search?q=` | GET | — | Search songs and albums |
| `/api/favorites` | GET | `X-Device-Id` | Get device's favorite songs |
| `/api/toggle_favorite` | POST | `X-Device-Id` | Toggle song favorite. Body: `song_id` |
| `/api/toggle_favorite_album` | POST | `X-Device-Id` | Toggle album favorite. Body: `album_id` |
| `/api/record_play` | POST | `X-Device-Id` | Record play start. Body: `song_id`. Returns `play_id` |
| `/api/update_play` | POST | `X-Device-Id` | Update play with duration. Body: `play_id`, `listened`, `duration`. Deletes if < 20s (false start) |
| `/api/auto_scan` | GET | — | Trigger library scan if files changed since last scan |
| `/api/stats` | GET | — | Get library statistics |
| `/api/app_version` | GET | — | Get current APP_VERSION from sw.js (bypasses SW cache) |
| `/api/app_icon` | GET | — | Serve app icon (first album cover) |
| `/api/record_share` | POST | `X-Device-Id` | Log outgoing share. Body: `song_id`, `album_id`, `share_method`, `share_type` |
| `/api/record_share_click` | POST | `X-Device-Id` | Log incoming share click. Body: `song_id`, `album_id`, `from_device_id`, `referrer` |
| `/api/log_event` | POST | `X-Device-Id` | Log playback event to daily log file |
| `/api/playback_logs` | GET | — | View recent logs. Query: `?date=YYYY-MM-DD&lines=N&type=error` |

### Virtual Albums

The player has two virtual albums that aren't real database records:

| ID | Title | Source | Cover Art |
|----|-------|--------|-----------|
| `"favorites"` | Favorites | `Favorite_model::get_favorites()` | Stacked covers from song art (1-3 images) |
| `"misc"` | Misc Songs | `Song_model::get_misc_songs()` | Placeholder "M" (no cover_url) |

### Response Field Conventions
- **Favorites toggle**: Always returns `is_favorite` (boolean) — never `favorited`
- **Song objects**: Include `stream_url`, `cover_url` (populated by `Song_model::populate_song_urls()`)
- **Album objects**: Include `cover_url` (from `Album_model::get_cover_url()`)
- **Duration**: Returned as STRING from database — JS must use `Number()` for arithmetic
- **POST data**: Player endpoints expect `application/x-www-form-urlencoded` (not JSON)

---

## Configuration

### File: `application/config/config.php`

| Key | Purpose | Notes |
|-----|---------|-------|
| `base_url` | Auto-detected from `$_SERVER['HTTP_HOST']` | Do NOT hardcode. Auto-detect ensures local dev (music.test) and production (music.glennbennett.com) both work. Hardcoding to production causes local JS/CSS to load from the production server. |

### File: `application/config/music_config.php`

| Key | Purpose | Example |
|-----|---------|---------|
| `music_origin_path` | Filesystem path to music directory | `/home/user/public_html/songs` |
| `music_cdn_url` | CDN URL for audio streaming | `https://glb-songs.b-cdn.net/songs` |
| `cover_art_url` | CDN URL for cover images | `https://glb-songs.b-cdn.net/songs/imgs` |
| `cover_art_path` | Filesystem path for covers (legacy) | `/home/user/public_html/songs/imgs` |
| `min_album_songs` | Min songs to form album | `2` |

### Path Relationships
```
music_origin_path = /home/user/public_html/songs
                    ├── *.mp3 (audio files)
                    └── imgs/
                        ├── albums/ (album covers)
                        └── songs/ (extracted song covers)

music_cdn_url     = https://cdn.example.com/songs (serves same structure)
cover_art_url     = https://cdn.example.com/songs/imgs
```

---

## CDN Architecture

### Overview
The system uses a **pull-zone CDN** (Bunny CDN) to serve media files. The CDN pulls from the origin server on first request, then caches files at edge locations.

### How It Works
```
User Request → CDN Edge → (Cache Miss?) → Origin Server
                  ↓                            ↓
              Cache Hit                    Fetch & Cache
                  ↓                            ↓
              Serve File ←←←←←←←←←←←←←←←← Return to Edge
```

### URL Mapping
| Content Type | Origin Path | CDN URL |
|--------------|-------------|---------|
| Audio files | `/songs/*.mp3` | `https://glb-songs.b-cdn.net/songs/*.mp3` |
| Album covers | `/songs/imgs/albums/*.jpg` | `https://glb-songs.b-cdn.net/songs/imgs/albums/*.jpg` |
| Song covers | `/songs/imgs/songs/*.webp` | `https://glb-songs.b-cdn.net/songs/imgs/songs/*.webp` |

### CDN Provider: Bunny CDN
- **Pull Zone**: `glb-songs.b-cdn.net`
- **Origin**: `glennbennett.com/songs`
- **Cache**: Automatic, edge-based

### Cache Behavior
- Files cached on first access
- Cache headers respected
- Purge via Bunny dashboard if needed

### URL Construction in Code
```php
// Audio streaming URL
$stream_url = $cdn_url . '/' . $song->filename;
// Example: https://glb-songs.b-cdn.net/songs/Colorado Snow.mp3

// Album cover URL (from flexible matching)
$cover_url = $cover_art_url . '/albums/' . $matched_file;
// Example: https://glb-songs.b-cdn.net/songs/imgs/albums/milestones.jpg

// Song cover URL (from database)
$cover_url = $cover_art_url . '/' . $song->cover_filename;
// Example: https://glb-songs.b-cdn.net/songs/imgs/songs/abc123.webp
```

### Important Notes
1. **Origin must be accessible** - CDN pulls from origin on cache miss
2. **File paths must match** - CDN URL structure mirrors origin
3. **No trailing slashes** - URLs constructed without trailing slashes
4. **Case sensitive** - File names are case-sensitive on origin

---

## Debugging

### Debug Endpoints

| URL | Purpose |
|-----|---------|
| `/share/debug/{song_id}` | Debug song cover lookup (CDN URLs) |
| `/share/test_image/{song_id}` | Debug share image generation (filesystem) |
| `/share/fonts` | Check if required fonts are installed |
| `/diagnose` | Full system diagnostics |

### Share Image Debug (`/share/test_image/{song_id}`)

Shows step-by-step:
1. **Configuration** - Paths being used
2. **Directory listing** - Files in albums directory
3. **Song info** - Title, cover_filename from database
4. **Album lookup** - Which album, normalized name for matching
5. **Cover path** - Final filesystem path found
6. **GD support** - Image format support
7. **Generated image** - Actual output

### Common Issues

#### Share image shows placeholder (no cover)
1. Visit `/share/test_image/{song_id}`
2. Check "music_origin_path exists?" - should be ✅
3. Check "albums dir exists?" - should be ✅
4. Check file listing matches album name
5. Verify normalized names match

#### Album cover not found
```php
// Album title: "Milestones"
// Normalized: "milestones" (lowercase, no separators)

// File must normalize to same:
// milestones.jpg → "milestones" ✓
// Milestones.jpg → "milestones" ✓
// Mile_Stones.jpg → "milestones" ✓
```

#### Facebook not showing image
1. Image must be publicly accessible
2. Use Facebook Sharing Debugger: `https://developers.facebook.com/tools/debug/`
3. Enter URL: `https://music.glennbennett.com/share/song/{id}`
4. Click "Scrape Again" to refresh cache

#### Fonts not working
1. Visit `/share/fonts`
2. Download missing fonts from Google Fonts
3. Upload to `/assets/fonts/`
4. Required: `PlayfairDisplay-Black.ttf`, `Montserrat-Regular.ttf`

### Diagnostic Checklist

#### Cover Art Not Loading
- [ ] `music_origin_path` set correctly in config?
- [ ] `/songs/imgs/albums/` directory exists on server?
- [ ] Album cover file exists with correct name?
- [ ] Filename normalizes to match album title?
- [ ] File readable by web server (permissions)?

#### CDN Not Serving Files
- [ ] Origin server accessible?
- [ ] File exists at origin path?
- [ ] CDN pull zone configured correctly?
- [ ] Try direct origin URL first

#### Share Image Generation
- [ ] GD library installed with JPEG/PNG/WebP support?
- [ ] Fonts uploaded to `/assets/fonts/`?
- [ ] Cover image loadable by GD?
- [ ] Memory limit sufficient for image processing?

### Logging

Add to controller for debugging:
```php
log_message('debug', 'Cover path: ' . $cover_path);
log_message('debug', 'File exists: ' . (file_exists($cover_path) ? 'yes' : 'no'));
```

Check logs at: `application/logs/log-{date}.php`

---

## Share Images & Social Sharing

### How Facebook Sharing Works
When a URL is shared on Facebook, the Facebook crawler fetches the page and reads OG meta tags. These tags tell Facebook what title, description, and image to show in the post. The crawler does NOT execute JavaScript, so all OG data must be in the server-rendered HTML.

### Two Share Paths
1. **Share via app buttons** (Share Song/Share Album): Uses `/share/song/{id}` or `/share/album/{id}` — these are dedicated redirect pages with full OG tags. Crawlers read the tags; humans get redirected to the player.
2. **Direct URL sharing** (user copies/pastes the player URL): Uses the main player page which also has OG tags server-rendered based on `$autoplay_song_id` and `$current_album`.

### Open Graph Meta Tags
Both the player page and the share redirect pages include these required OG tags:
- `og:type` — Always `music.song`
- `og:title` — Song/album title + "Glenn Bennett", or "Glenn Bennett Music" for generic
- `og:description` — "Listen to [title] by Glenn L. Bennett", or generic description
- `og:image` — Points to `/share/image?song={id}` or `/share/image?album={id}` or `/share/image` for generic
- `og:image:width` — 1200
- `og:image:height` — 630
- `og:url` — Canonical URL
- `og:site_name` — "Glenn Bennett Music"
- Twitter Card tags are also included (`twitter:card`, `twitter:title`, `twitter:description`, `twitter:image`)

### Share Image Generation
- Endpoint: `/share/image?song={id}` or `/share/image?album={id}` or `/share/image` (generic)
- Generates 1200x630 JPEG using GD library
- Layout: album cover art on left side, title/artist text on right
- Falls back to album cover if song-specific cover not found
- Falls back to placeholder (music note icon) if no cover art found
- Falls back to simple text-only image if GD or fonts fail
- Fonts required: `PlayfairDisplay-Black.ttf`, `Montserrat-Regular.ttf` in `/assets/fonts/`
- If fonts are missing, uses built-in GD bitmap fonts (uglier but functional)
- Error handling: try/catch with `log_message()` — errors are logged, not suppressed

### Share Redirect Page
- Endpoint: `/share/song/{id}` or `/share/album/{id}`
- View: `application/views/share/og_redirect.php`
- HTML page with full OG tags + immediate redirect to player
- Facebook/Twitter crawlers read OG tags from this page
- Human visitors are redirected via `<meta http-equiv="refresh">` and JavaScript

### Native Share (navigator.share)
- Uses the `/share/song/{id}` URL so the shared link has proper OG tags
- Falls back to share options modal (Facebook/Twitter/Copy Link) if navigator.share unavailable

### Testing Facebook Share Images
1. **Check OG tags locally**: View page source of `http://music.test/share/song/{id}` — verify og:title, og:description, og:image are present
2. **Test image generation locally**: Visit `http://music.test/share/image?song={id}` — should render a JPEG image
3. **Use built-in debug tool**: Visit `http://music.test/share/test_image/{song_id}` — shows config paths, cover art status, font status, and the generated image
4. **Use built-in debug tool**: Visit `http://music.test/share/debug/{song_id}` — shows song data, cover URLs, and fetch tests
5. **Test on production**: After deploying, use the [Facebook Sharing Debugger](https://developers.facebook.com/tools/debug/) — paste the share URL and click "Debug". This shows exactly what Facebook sees.
6. **Scrape fresh**: If Facebook has cached old data, click "Scrape Again" in the debugger to force a re-fetch
7. **Check for errors**: In the debugger, look for warnings about missing tags or inaccessible images

---

## Favorites System

### Architecture
- **All favorites logic lives in `Favorite_model.php`** — no favorites code in Song_model, Album_model, or inline in controllers
- Favorites are per-device (identified by `device_id` stored in localStorage)
- There is no user account system — favorites are tied to the browser/device
- The `favorites` table uses `device_id` (VARCHAR) as part of the primary key, NOT `user_id`
- `Favorite_model::ensure_device()` auto-creates a device row before inserting favorites (FK constraint)

### Favorite_model Methods
| Method | Returns | Description |
|--------|---------|-------------|
| `is_favorite($device_id, $song_id)` | bool | Check if song is favorited |
| `get_favorites($device_id)` | array of song objects | All favorites with stream_url/cover_url populated |
| `toggle_favorite($device_id, $song_id)` | `['is_favorite' => bool]` | Add or remove favorite |
| `is_album_favorite($device_id, $album_id)` | bool | Check if album is favorited |
| `get_favorite_albums($device_id)` | array of album objects | All favorite albums with cover_url |
| `toggle_album_favorite($device_id, $album_id)` | `['is_favorite' => bool]` | Add or remove album favorite |

### Favorites in the Player (JS Behavior)
- **Heart icon**: Shows filled/unfilled based on actual server state (checked via `checkFavoriteStatus()` on every track change)
- **Toggle**: `toggleFavorite()` sends POST to `/player/toggle_favorite` with `X-Device-Id` header and `song_id` as form-encoded body
- **Debounce**: `_togglingFavorite` flag prevents rapid double-clicks from firing multiple requests
- **Unfavorite while viewing Favorites**: Song is immediately removed from the track list and the album re-renders
- **Dropdown position**: "Favorites" appears at the END of the album dropdown (before "Misc Songs"), not at the top
- **Dropdown sync**: `syncFavoritesOption()` adds/removes the Favorites option based on whether the device has any favorites
- **Stacked cover art**: When viewing Favorites, the album cover area shows a stack of up to 3 unique song cover images (fanned from bottom-left to upper-right with rotation and shadows). Falls back to "F" placeholder if no songs have covers.

### Database: `favorites` Table
| Column | Type | Description |
|--------|------|-------------|
| device_id | VARCHAR(64) | FK to devices.id (part of PK) |
| song_id | INT | FK to songs.id (part of PK) |
| sort_order | INT | Display order |
| created_at | DATETIME | When favorited |

**Primary key**: `(device_id, song_id)`

### Database: `favorite_albums` Table
| Column | Type | Description |
|--------|------|-------------|
| device_id | VARCHAR(64) | FK to devices.id (part of PK) |
| album_id | INT | FK to albums.id (part of PK) |
| created_at | DATETIME | When favorited |

**Primary key**: `(device_id, album_id)`

---

## Service Worker (PWA)

### File: `sw.js`

### Features
- Caches static assets on install
- Offline playback via audio file caching
- Background precache of all songs on activate
- Update detection and in-app update banner

### Cache Strategy
- **Navigation requests (HTML pages)**: Network-first — always loads fresh HTML when online, falls back to cache when offline
- **Static assets (JS/CSS)**: Network-first — always loads fresh files when online, falls back to cache when offline. This ensures version bumps take effect immediately without manual cache clearing.
- **API calls**: Network-first, cache fallback for offline
- **Audio files**: Cache-first for offline playback; range requests go to network with background caching of full file
- **Images**: Cache-first

### Update Flow
1. Browser checks for new `sw.js` on each page load and hourly
2. If `sw.js` has changed, browser downloads and installs the new SW
3. New SW caches fresh static assets (JS/CSS/HTML) during install
4. Update banner appears: "New version available"
5. User clicks "Update" → new SW activates → `controllerchange` fires → page reloads
6. Page loads fresh HTML (network-first) with updated version

### Version Sync
**FOUR places must stay in sync on every release:**
1. `sw.js` → `const APP_VERSION = '3.0.X'` (line 3)
2. `application/views/player/index.php` → `menuVersion` span (e.g., `v3.0.X`)
3. `application/views/player/index.php` → `?v=3.0.X` query strings on CSS and JS `<link>`/`<script>` tags
4. `REQUIREMENTS.md` → Current Version header + APP_VERSION line + version history table row

### Current Version
Updated with each release: `const APP_VERSION = '3.0.53'`

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 3.0.53 | 2026-02-22 | Fixed progress bar grey track not visible (was using background-clip hack, now uses separate .progress-track div); improved mainPlayToggle logic to check audio.paused state directly |
| 3.0.52 | 2026-02-22 | Changed SW static asset strategy from cache-first to network-first so JS/CSS updates take effect immediately without needing manual cache clear |
| 3.0.51 | 2026-02-22 | Removed artist name from track list and album info (single-artist app, not needed) |
| 3.0.50 | 2026-02-22 | Unified server-rendered album_content.php to match JS renderAlbum() (same track-thumb/track-number, track-artist, album-meta, stacked covers); stacked covers now work for ALL albums without cover_url (not just Favorites); removed old mashup-cover and colored SVG placeholder code |
| 3.0.49 | 2026-02-22 | Fixed progress bar handle z-index (fill bar was rendering in front of the scrub handle) |
| 3.0.48 | 2026-02-22 | Track list text flush left (was inheriting text-align:center); added .track-artist styling; progress bar with draggable handle, bigger touch target, touch/mouse scrubbing; progress handle tracks playback position; totalTime resets on track switch |
| 3.0.47 | 2026-02-22 | Fixed album total duration showing scientific notation (string concatenation instead of numeric addition) |
| 3.0.46 | 2026-02-22 | Favorites and Misc moved to end of album dropdown; unfavoriting a song while viewing Favorites now removes it from the list immediately |
| 3.0.45 | 2026-02-22 | Stacked cover art for Favorites album (1-3 song covers layered with shadows); song cover thumbnails in track list replace plain track numbers; added CSS for .stacked-covers, .track-number, .track-thumb |
| 3.0.44 | 2026-02-22 | Centralized favorites into Favorite_model; removed duplicate favorites code from Song_model, Album_model, and inline DB queries in Api.php; normalized all responses to use `is_favorite` (not `favorited`); fixed checkFavoriteStatus to actually query server; added is_favorite endpoint to Player; added debounce to toggleFavorite; fixed JS POST encoding (was JSON, now form-encoded); updated schema.sql favorites tables to use device_id as primary key |
| 3.0.43 | 2026-02-22 | Reset playback position to 0 when track finishes or user skips; progress bar clears immediately on track switch; share images use Poppins font, right-aligned branding with website URL, smarter text wrapping (shorter first line); fixed duplicate Misc album link for songs already in a real album |
| 3.0.43 | 2026-02-21 | Fixed Facebook sharing: added og:type, og:title, og:description, Twitter Card tags to main player view; added fallback og:image for generic shares; removed error_reporting(0) from share image generation and added try/catch with logging; added generate_fallback_image() for when GD fails |
| 3.0.41 | 2026-02-21 | Fixed base_url to auto-detect host (was hardcoded to production, causing local JS/CSS to load from production server instead of local machine) |
| 3.0.40 | 2026-02-21 | MediaSession: re-register ALL action handlers on every track change (iOS drops them on metadata update); added setPositionState for duration info; multiple artwork sizes; "Up to date" now shows version number |
| 3.0.38 | 2026-02-21 | CarPlay/lock screen: removed all seekbackward/seekforward handler registration — any registration causes iOS to show seek buttons; leaving them unregistered lets iOS show skip track buttons |
| 3.0.37 | 2026-02-21 | Updates now auto-apply: Check for Updates closes menu and reloads immediately; new service workers auto-activate on install instead of waiting for banner click |
| 3.0.36 | 2026-02-21 | CarPlay/MediaSession: seekbackward/seekforward now map to previousTrack/nextTrack instead of no-op — ensures skip behavior regardless of what buttons Safari shows |
| 3.0.35 | 2026-02-20 | Fixed auto-play on album switch (audio error event from clearing src triggered nextTrack); renamed all "Unknown Album" references to "Misc" across admin views/controllers; scanner auto-renames existing "Unknown Album" DB records to "Misc" on scan |
| 3.0.34 | 2026-02-20 | Fixed updates not applying: navigation requests now use network-first strategy so page always loads fresh HTML; added version query strings to JS/CSS includes for cache-busting; fixed applyUpdate race condition (controllerchange handler does the reload) |
| 3.0.33 | 2026-02-20 | Fixed album switcher (loadAlbum waits for fetch before clearing playback); favorites model uses device_id instead of user_id; Favorites option only shown when favorites exist (syncFavoritesOption); renamed "Unknown Album" to "Misc" in scanner |
| 3.0.32 | 2026-02-20 | Fixed master Play button: added id="mainPlayBtn" and changed to mainPlayToggle() so it syncs play/pause state with the rest of the player |
| 3.0.31 | 2026-02-20 | Dynamic music_origin_path resolution (local Herd + production); cover_art_path derived from music_origin_path; filesystem scan is never skipped |
| 3.0.30 | 2026-02-20 | CarPlay: seekbackward/seekforward use no-op handlers instead of null to prevent default seek fallback; added dynamic og:image to player/index.php for Facebook sharing; fixed MediaSession play handler to use audio.paused instead of stale isPlaying; added visibilitychange handler to re-register MediaSession and recover stalled audio after phone sleep/car reconnect |
| 3.0.29 | 2026-02-18 | Fixed update loop: synced menuVersion in index.php with sw.js; native share now uses /share/ URLs for OG tags |
| 3.0.28 | 2026-02-18 | Fixed share URLs in navigator.share (BROKEN - missed index.php version sync) |
| 3.0.27 | 2026-02-18 | Fixed share image paths, added CDN docs, debugging section |
| 3.0.26 | 2026-02-18 | Restored flexible cover matching, added REQUIREMENTS.md |
| 3.0.25 | 2026-02-18 | Simplified issue detection, misc is informational |
| 3.0.24 | 2026-02-18 | Fixed $track_numbers variable error |
| 3.0.23 | 2026-02-18 | Simplified cover art (BROKEN - removed flexible matching) |
| 3.0.22 | 2026-02-18 | Sort by file track#, sortable tables |
| 3.0.21 | 2026-02-18 | Added File# column, track mismatch detection |
| 3.0.20 | 2026-02-18 | Album diagnostics, multi-album detection |
| 3.0.19 | 2026-02-18 | Songs detail view with updated_at |
| 3.0.18 | 2026-02-18 | Complete field listing in albums view |
| 3.0.17 | 2026-02-17 | Admin albums with track details |
| 3.0.10-16 | 2026-02-17 | Share image generator development |
| 3.0.x | 2026-01-30 | Initial flexible cover matching |

---

## Rules for Development

### Before Making Changes
1. **Read this document**
2. **Check relevant section** for existing behavior
3. **Understand the "why"** before changing

### Core Rules
1. **MP3 files are the source of truth** for song/album data
2. **Never remove filesystem scanning** for album covers
3. **Always use flexible matching** (case-insensitive, ignore separators)
4. **Misc songs are not errors** - they're songs without album assignment
5. **Track order comes from MP3 files**, not database
6. **Keep it simple** - avoid over-engineering

### After Making Changes
1. **Update this document** with new behavior
2. **Add to version history**
3. **Test the affected functionality**
4. **Bump version** in all 4 places (sw.js, index.php x2, REQUIREMENTS.md)

### Common Pitfalls (Things That Have Broken Before)

| Pitfall | What Went Wrong | Prevention |
|---------|----------------|------------|
| **base_url hardcoded** | Local dev loaded JS/CSS from production; all local changes had no effect | `base_url` must auto-detect from `$_SERVER['HTTP_HOST']` — NEVER hardcode |
| **API returns strings** | `duration` is `"218"` not `218`; JS `reduce` concatenated strings → `"0218195..."` → scientific notation | Always use `Number()` or `parseInt()` when doing math on API values |
| **Favorites field name** | Some endpoints returned `favorited`, others `is_favorite`; JS checked wrong field | ALL favorites responses must use `is_favorite` — centralized in `Favorite_model` |
| **POST encoding** | JS sent `Content-Type: application/json` but PHP `$this->input->post()` expects form-encoded | Player POST requests use `application/x-www-form-urlencoded` with `key=value` body |
| **FK constraint on favorites** | Insert into `favorites` failed silently because `device_id` FK references `devices.id` and device didn't exist | `Favorite_model::ensure_device()` creates the device row before inserting |
| **Setting `audio.src = ''`** | Fires the `error` event, which triggered `nextTrack()` causing auto-play on album switch | Guard in error handler: skip if `!this.audio.src` |
| **Service Worker caching** | Cache-first for JS/CSS meant old SW kept serving stale files even after version bumps | Fixed in 3.0.52: ALL assets now network-first. NEVER change static assets back to cache-first. |
| **"Unknown Album" vs "Misc"** | Old DB records and some views still said "Unknown Album" | Scanner renames on scan; name is always "Misc" in all files including admin views |
| **Favorites code scattered** | Duplicate favorites logic in Song_model, Album_model, Api.php, Player.php | ALL favorites logic in `Favorite_model.php` only — no inline DB queries |
| **Favorites dropdown position** | `syncFavoritesOption()` used `prepend()` putting Favorites at top of list | Use `insertBefore(miscOption)` or `appendChild()` to put it at end |
| **database/ directory** | Old SQL backup files — editing them has no effect | Don't edit files in `database/` — they're backups, not live schema |

---

## Known Issues / TODOs

- [ ] Album cover upload in admin UI
- [ ] Bulk edit for song metadata
- [ ] Playlist support
- [ ] User favorites sync across devices

---

## Contact

System maintained by Glenn Bennett.  
Application: https://music.glennbennett.com
